from .tossicat import *

__doc__ = tossicat.__doc__
if hasattr(tossicat, "__all__"):
    __all__ = tossicat.__all__